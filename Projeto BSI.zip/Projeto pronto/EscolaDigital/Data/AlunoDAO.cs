﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Linq;
using EscolaDigital.Model;
using Dapper;


namespace EscolaDigital.Data
{
    public class AlunoDAO
    {
        Conexao con = new Conexao();

        //GetAlunos
        public static List<Retorno> GetAlunos()
        {
            using (IDbConnection conn = new Conexao().conn)
            {
                var output = conn.Query<Retorno>("SELECT E.Id,E.Produto,E.preco,E.Quantidade,L.Cidade,L.Estado, L.Id as LocalId FROM Estoque E LEFT JOIN Local L ON E.Id = L.FK_Id_Estoque", new DynamicParameters());
                return output.ToList();
            }
        }

        public class Retorno
        {
            public int Id { get; set; }
            public string Cidade { get; set; }
            public string Estado { get; set; }
            public string Produto { get; set; }
            public string Preco { get; set; }
            public int Quantidade { get; set; }

            public int LocalId { get; set; }
            

        }



        //GetProdutos
        public static Estoque GetAluno(int id)
        {
            using(IDbConnection conn = new Conexao().conn)
            {
                var output = conn.Query<Estoque>("SELECT * FROM Estoque WHERE Id = " + id, new DynamicParameters());
                return output.First();
            }
        }

        //InsereProdutos
        public static int InsereAluno(Estoque aluno)
        {
            using(IDbConnection conn = new Conexao().conn)
            {
                conn.Execute("INSERT INTO Estoque(Produto, Preco, Quantidade) VALUES(@Produto, @Preco, @Quantidade)", aluno);

                var id = conn.Query<int>("SELECT seq FROM sqlite_sequence where name = 'Estoque'");
                return id.Single();
            }
        }

        //InsereCidadeEstado
        public static void InsereLocal(Local aluno)
        {
            using (IDbConnection conn = new Conexao().conn)
            {
                conn.Execute("INSERT INTO Local(Cidade, Estado, FK_Id_Estoque) " +
                    "VALUES(@Cidade, @Estado, @FK_Id_Estoque)", aluno);
            }
        }

        //AtualizaProdutos
        public static void AtualizaAluno(Estoque aluno)
        {
            using(IDbConnection conn = new Conexao().conn)
            {
                conn.Execute("UPDATE Estoque SET Produto=@Produto, Preco=@Preco, Quantidade=@Quantidade WHERE Id=@Id", aluno);
            }
        }

        public static void AtualizaLocal(Local local)
        {
            using (IDbConnection conn = new Conexao().conn)
            {
                conn.Execute("UPDATE Local SET Cidade=@Cidade, Estado=@Estado WHERE Id=@Id", local);
            }
        }

        //DeletaAluno
        public static void DeleteAluno(int aluno)
        {
            var newEstoque = new Estoque();
            newEstoque.Id = aluno;
            using (IDbConnection conn = new Conexao().conn)
            {
                conn.Execute("DELETE FROM Estoque WHERE Id=@Id", newEstoque);
             
            }
        }
    }
}
