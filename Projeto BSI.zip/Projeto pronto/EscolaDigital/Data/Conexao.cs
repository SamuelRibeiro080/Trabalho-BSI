﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SQLite;

namespace EscolaDigital.Data
{
    public class Conexao
    {
        // Objeto de conexão com banco SQLite
        public SQLiteConnection conn = new SQLiteConnection("Data Source = Escola.db");

        public void conectar()
        {
            conn.Open();
        }
        public void desconectar()
        {
            conn.Close();
        }
    }
}
