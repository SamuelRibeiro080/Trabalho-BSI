﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EscolaDigital.Data;
using EscolaDigital.Model;
using static EscolaDigital.Data.AlunoDAO;

namespace EscolaDigital
{
    public partial class MainWindow : Window
    {
        public AlunoDAO alunoDAO = new AlunoDAO();
        Estoque novoAluno = new Estoque();
        Local novoLocal = new Local();
        Estoque selectedAluno = new Estoque();
        Local selectedLocal = new Local();
        string action = "adicionar";


        public MainWindow()
        {
            InitializeComponent();
            GetAlunos();
            AlunoGrid.DataContext = novoAluno;
            LocalGrid.DataContext = novoLocal;
        }

        private void GetAlunos()
        {
            alunosDataGrid.ItemsSource = AlunoDAO.GetAlunos();
        }


        private void SelectAlunoToEdit(object sender, RoutedEventArgs e)
        {
            //pegando aluno e local da grid(tela)
            Retorno retorno = (sender as FrameworkElement).DataContext as Retorno;

            //aluno
            selectedAluno = new Estoque()
            {
                Id = retorno.Id,
                Preco = retorno.Preco,
                Produto = retorno.Produto,
                Quantidade = retorno.Quantidade
            };
            AlunoGrid.DataContext = selectedAluno;

            //local
            selectedLocal = new Local()
            {
                Id = retorno.LocalId,
                Cidade = retorno.Cidade,
                Estado = retorno.Estado
            };
            LocalGrid.DataContext = selectedLocal;

            action = "editar";
        }

        private void DeleteAluno(object sender, RoutedEventArgs e)
        {
            var alunoToDelete = (sender as FrameworkElement).DataContext;
            Console.WriteLine($"{alunoToDelete}");

            if (MessageBox.Show("Tem certeza que deseja apagar o produto " + alunoToDelete.GetType().GetProperty("Id").GetValue(alunoToDelete) + "?", "Confirmação", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.No)
            {

            }
            else
            {
                AlunoDAO.DeleteAluno((int)alunoToDelete.GetType().GetProperty("Id").GetValue(alunoToDelete));
                GetAlunos();
            }



        }

        private void AlunoConfirm(object sender, RoutedEventArgs e)
        {
            try
            {

                if (action == "adicionar")
                {
                    var id = AlunoDAO.InsereAluno(novoAluno);
                    novoLocal.FK_Id_Estoque = id;
                    AlunoDAO.InsereLocal(novoLocal);
                    GetAlunos();

                    novoAluno = new Estoque();
                    novoLocal = new Local();
                    AlunoGrid.DataContext = novoAluno;
                    LocalGrid.DataContext = novoLocal;
                }
                else if (action == "editar")
                {
                    AlunoDAO.AtualizaAluno(selectedAluno);
                    AlunoDAO.AtualizaLocal(selectedLocal);
                    GetAlunos();

                    //refresh campos
                    novoAluno = new Estoque();
                    novoLocal = new Local();
                    AlunoGrid.DataContext = novoAluno;
                    LocalGrid.DataContext = novoLocal;
                    action = "adicionar";
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Erro ao {action} \n" + exception.Message, "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }

        private void alunosDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
