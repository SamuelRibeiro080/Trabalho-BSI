﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EscolaDigital.Model
{
    public class Estoque
    {
        public int Id { get; set; }
        public string Produto { get; set; }
        public string Preco { get; set; }
        public int Quantidade { get; set; }
    }
}
