﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace EscolaDigital.Model
{
    public class Local
    {
        public int Id { get; set; }
        public string Cidade { get; set; }
        public string Estado { get; set; }
        public int FK_Id_Estoque { get; set; }


    }
}
